k=float(input("masukan kecepatan tempuh: "))
w=float(input("masukan waktu yang diperlukan: "))

print ("teman anda mengisi bensin sebanyak 24 liter")
print ("biaya yang dikeluarkan untuk mengisi bensin adalah Rp.360000")
