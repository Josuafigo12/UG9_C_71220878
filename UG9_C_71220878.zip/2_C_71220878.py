nama = str(input("masukan nama anda: "))
mata_kuliah = str(input("masukan mata kuliah: "))
grub = str(input("masukan grub: "))

print("haloo! " +str(nama))
print("Alaska tergabung dalam kelas " + str(mata_kuliah))
print("pada grub " + str(grub))
